#include "types.h"
#include "stat.h"
#include "user.h"

void inv(char *c)
{
  if(*c>='a'&&*c<='z')
    *c-=('a'-'A');
  else if(*c>='A'&&*c<='Z')
    *c+=('a'-'A');
}

char* Inv(char *c)
{
  int i=0;
  while(*(c+i))
    inv(c+i++);
  return c;
}

int
main(int argc, char *argv[])
{
  int i;

  for(i = 1; i < argc; i++)
    printf(1, "%s%s", Inv(argv[i]), i+1 < argc ? " " : "\n");
  exit();
}