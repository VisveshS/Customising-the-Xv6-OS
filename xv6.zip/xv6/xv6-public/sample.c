#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
	float x=1.0,i;
	for(i=0.0;i<400000;i+=0.01)
		x*=1.00000012345;
	exit();
}
