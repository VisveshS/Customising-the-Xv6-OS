#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  if(argc <= 1)
  	exit();	
  int pid=atoi(argv[1]);
  int newpriority=atoi(argv[2]);
  if(newpriority>100)
  	goto invalid;
  if(argv[2][0]=='-')
  	goto invalid;
  goto print;
  invalid:
  {
  	printf(2,"invalid priority\n");
  	exit();
  }
  print:
  printf(1,"priority changed successfuly\n");
  set_priority(pid,newpriority);
  exit();
}
